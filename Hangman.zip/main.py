from replit import clear
import random

#importing hangman_words module
import hangman_words
chosen_word = random.choice(hangman_words.word_list)
word_length = len(chosen_word)

end_of_game = False
lives = 6

#importing hangman_art module for logo and stages ascii art
import hangman_art
print(hangman_art.logo)

#Testing code
# print(f'Pssst, the solution is {chosen_word}.')
print("_" * len(chosen_word))
#Create blanks
display = []
for _ in range(word_length):
    display += "_"

while not end_of_game:
    guess = input("Guess a letter: ").lower()
    #clear the screen after every guess
    clear()

    #if the user enters an already guessed letter.
    if guess in display:
      print(f"You have already guessed {guess}")

    #Check guessed letter
    for position in range(word_length):
        letter = chosen_word[position]
        # print(f"Current position: {position}\n Current letter: {letter}\n Guessed letter: {guess}")
        if letter == guess:
            display[position] = letter

    #Check if user is wrong.
    if guess not in chosen_word:
        print(f"'{guess}' is not in the word. You lose a life")
        lives -= 1
        if lives == 0:
            end_of_game = True
            print(f"You lose. The word is {chosen_word}")

    #Join all the elements in the display list and turn it into a String.
    print(f"{' '.join(display)}")

    #Check if user has got all letters.
    if "_" not in display:
        end_of_game = True
        print("You win.")

    #hangman lives ascii art
    print(hangman_art.stages[lives])
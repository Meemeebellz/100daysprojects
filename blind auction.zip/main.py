from replit import clear
from art import logo
print(logo)
print("Welcome to La Secret Auction\n")

bidders_list = []
def bidders(name, bid):
  bidder_dict = {}
  bidder_dict[name] = bid
  bidders_list.append(bidder_dict)

other_bidders = "yes"
while other_bidders == "yes":

  bidder_name = input("Enter your name: ").title()
  bid_amount = float(input("Enter bid amount: $"))
  print("\n\n")
  other_bidders = input("Are there other bidders? Type 'Yes' or 'No': ").lower()

  clear()
  bidders(name=bidder_name, bid=bid_amount)

max_bid = 0
max_bidder = ""
for bidder_dict in bidders_list:
  for name in bidder_dict:
    if bidder_dict[name] > max_bid:
      max_bid = bidder_dict[name]
      max_bidder = name
print(f"The winner of this auction is {max_bidder} with a bid of ${max_bid}.")
  


  